import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Main {
    public static void main(String[] args) {
        try {
            Scanner fileScanner = GetInputFile("Enter the filename (including path if necessary): ");
            aOrderedList orderedList = new aOrderedList();

            if (fileScanner != null) {
                while (fileScanner.hasNextLine()) {
                    String line = fileScanner.nextLine();
                    String[] parts = line.split(",");

                    if (parts.length > 0) {
                        if (parts[0].equalsIgnoreCase("A")) {
                            // Add operation
                            if (parts.length == 4) {
                                String make = parts[1].trim();
                                int year = Integer.parseInt(parts[2].trim());
                                int price = Integer.parseInt(parts[3].trim());
                                Car car = new Car(make, year, price);
                                orderedList.add(car);
                            } else if (parts[0].equalsIgnoreCase("D")) {
                                // Delete operation
                                if (parts.length == 2) {
                                    int index = Integer.parseInt(parts[1].trim());
                                    if (index >= 0 && index < orderedList.size()) {
                                        orderedList.remove(index);
                                    }
                                }
                            }
                        }
                    }
                }

                fileScanner.close();

                // Get the output file and write the formatted content
                PrintWriter outputFile = GetOutputFile("Enter the output filename (including path if necessary): ");
                if (outputFile != null) {
                    printFormattedList(orderedList, outputFile);
                    outputFile.close();
                    System.out.println("Formatted content has been written to the output file.");
                }
            } else {
                System.out.println("Program execution canceled.");
            }
        } catch (FileNotFoundException e) {
            System.err.println("File not found or an error occurred: " + e.getMessage());
        }
    }

    public static Scanner GetInputFile(String userPrompt) {
        Scanner scanner = new Scanner(System.in);
        Scanner fileScanner = null;
        boolean continuePrompt = true;

        do {
            System.out.print(userPrompt);
            String filename = scanner.nextLine();
            try {
                File file = new File(filename);
                if (file.exists() && file.isFile()) {
   //                 fileScanner = new Scanner(file);
                    continuePrompt = false;
                } else {
                    System.out.println("File specified <" + filename + "> does not exist.");
                    System.out.print("Would you like to continue? <Y/N> ");
                    String userResponse = scanner.nextLine();
                    if (userResponse.equalsIgnoreCase("N")) {
                        continuePrompt = false;
                    }
                }
            } catch (SecurityException e) {
                System.err.println("Security Exception: " + e.getMessage());
            }
        } while (continuePrompt);

        return fileScanner;
    }


    public static PrintWriter GetOutputFile(String userPrompt) throws FileNotFoundException {
        PrintWriter printWriter = null;
        boolean continuePrompt = true;

        do {
            Scanner scanner = new Scanner(System.in);
            System.out.print(userPrompt);
            String filename = scanner.nextLine();
            try {
                File file = new File(filename);

                if (file.getParentFile() != null) {
                    file.getParentFile().mkdirs();
                }

                printWriter = new PrintWriter(file);
                continuePrompt = false;
            } catch (SecurityException e) {
                System.err.println("Security Exception: " + e.getMessage());
            }
        } while (continuePrompt);

        return printWriter;
    }

    public static void printFormattedList(aOrderedList orderedList, PrintWriter output) {
        // Output the size of the array
        output.println(orderedList.size());

        // Output the formatted content of the array
        for (int i = 0; i < orderedList.size(); i++) {
            output.println();
            Car car = orderedList.get(i);
            output.println("Make: " + car.getMake());
            output.println("Year: " + car.getYear());
            output.println("Price: " + car.getPrice());
        }
    }
}

