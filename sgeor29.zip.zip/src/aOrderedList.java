import java.util.Arrays;

public class aOrderedList {
    private final int SIZEINCREMENTS = 20;
    private Car[] oList;
    private int listSize;
    private int numObjects;

    public aOrderedList() {
        numObjects = 0;
        listSize = SIZEINCREMENTS;
        oList = new Car[listSize];
    }

    public void add(Car newCar) {
        if (numObjects == listSize) {
            // If the list is full, expand it
            expandList();
        }

        // Find the index where the newCar should be inserted to maintain sorted order
        int index = 0;
        while (index < numObjects && newCar.compareTo(oList[index]) >= 0) {
            index++;
        }

        // Shift elements to make space for the newCar
        for (int i = numObjects; i > index; i--) {
            oList[i] = oList[i - 1];
        }

        // Insert the newCar at the correct index
        oList[index] = newCar;
        numObjects++;
    }

    public int size() {
        return numObjects;
    }

    public Car get(int index) {
        if (index < 0 || index >= numObjects) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
        return oList[index];
    }

    public boolean isEmpty() {
        return numObjects == 0;
    }

    public void remove(int index) {
        if (index < 0 || index >= numObjects) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }

        for (int i = index; i < numObjects - 1; i++) {
            oList[i] = oList[i + 1];
        }

        oList[numObjects - 1] = null; // Clear the last element
        numObjects--;

        // If the number of empty slots exceeds a certain threshold, shrink the array
        if (listSize - numObjects > SIZEINCREMENTS) {
            shrinkList();
        }
    }

    public String toString() {
        StringBuilder result = new StringBuilder("Number of cars: " + numObjects + "\n");
        for (int i = 0; i < numObjects; i++) {
            result.append("Make: ").append(oList[i].getMake()).append("\n");
            result.append("Year: ").append(oList[i].getYear()).append("\n");
            result.append("Price: $").append(oList[i].getPrice()).append("\n\n");
        }
        return result.toString();
    }

    private void expandList() {
        int newSize = listSize + SIZEINCREMENTS;
        oList = Arrays.copyOf(oList, newSize);
        listSize = newSize;
    }

    private void shrinkList() {
        int newSize = listSize - SIZEINCREMENTS;
        oList = Arrays.copyOf(oList, newSize);
        listSize = newSize;
    }
}
