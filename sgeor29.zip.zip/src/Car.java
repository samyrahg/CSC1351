public class Car implements Comparable<Car> {

    private String Make;
    private int Year;
    private int Price;

    public Car(String Make, int Year, int Price) {
        this.Make = Make;
        this.Year = Year;
        this.Price = Price;
    }

    public String getMake() {
        return Make;
    }

    public int getYear() {
        return Year;
    }

    public int getPrice() {
        return Price;
    }

    @Override
    public int compareTo(Car other) {
        // Compare cars based on make, year, and price
        if (!Make.equals(other.Make)) {
            return Make.compareTo(other.Make);
        } else if (Year != other.Year) {
            return Integer.compare(Year, other.Year);
        } else {
            // If make and year are equal, compare based on price
            return Integer.compare(Price, other.Price);
        }
    }

    @Override
    public String toString() {
        return "Make: " + Make + ", Year: " + Year + ", Price: " + Price;
    }
}
